# 🚀 rapidAid Setup Guide

## Step 1: Install Node.js

Node.js is required to run the backend server. 

### Download and Install:
1. Visit: https://nodejs.org/
2. Download the LTS (Long Term Support) version
3. Run the installer and follow the setup wizard
4. Restart your terminal/command prompt after installation

### Verify Installation:
Open a new terminal and run:
```bash
node --version
npm --version
```

Both commands should show version numbers.

## Step 2: Install Dependencies

Once Node.js is installed, navigate to the project folder and run:

```bash
npm install
```

This will install all required packages (Express, SQLite, Socket.IO, JWT, bcrypt, Axios, etc.).

## Step 3: Start the Backend Server

Run the following command to start the backend:

```bash
npm start
```

You should see:
```
🚑 rapidAid server running on http://localhost:3000
📊 API endpoints available at http://localhost:3000/api/
Connected to SQLite database
Patients table ready
Drivers table ready
Hospitals table ready
```

## Step 4: Open the Application

### Option 1: Through Backend Server (Recommended)
Open your browser and go to:
```
http://localhost:3000
```

### Option 2: Direct File Access
Simply open `index.html` in your browser (management features won't work without backend)

## 🎯 Quick Start Commands

```bash
# Install dependencies (first time only)
npm install

# Start the server
npm start

# For development with auto-restart (optional)
npm install -g nodemon
npm run dev
```

## ✅ Verification Checklist

- [ ] Node.js installed and verified
- [ ] Dependencies installed (`npm install` completed)
- [ ] Backend server running (`npm start` shows success message)
- [ ] Database file created (`rapidaid.db` appears in project folder)
- [ ] Application opens in browser
- [ ] Can navigate between views
- [ ] Can add patients in Management view
- [ ] Can add drivers in Management view

## 🔧 Troubleshooting

### "npm is not recognized"
- Node.js is not installed or not in PATH
- Restart terminal after installing Node.js
- Reinstall Node.js if issue persists

### "Port 3000 already in use"
- Another application is using port 3000
- Close that application or change the port in `server.js`

### "Cannot find module"
- Run `npm install` again
- Delete `node_modules` folder and `package-lock.json`, then run `npm install`

### Database errors
- Make sure you have write permissions in the project folder
- Delete `rapidaid.db` to reset the database

## 📝 Notes

- Keep the backend server running while using the application
- Create a `.env` file (see sample below) to set secrets/API keys
- The database is created automatically on first run (`rapidaid.db`)
- Frontend works standalone but backend is needed for real-time tracking, auth, and persistence

### Sample `.env`
```
PORT=3000
JWT_SECRET=super-secret-key
ORS_API_KEY=your_openrouteservice_key   # optional for live routing
```

