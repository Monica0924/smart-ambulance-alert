const http = require('http');
const path = require('path');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const { Server } = require('socket.io');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const axios = require('axios');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'rapidaid-secret';
const ORS_API_KEY = process.env.ORS_API_KEY || '';

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

const db = new sqlite3.Database('./rapidaid.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

function initializeDatabase() {
    const queries = [
        `CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            phone TEXT NOT NULL,
            severity TEXT NOT NULL,
            condition TEXT,
            hospital TEXT NOT NULL,
            status TEXT DEFAULT 'Active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS drivers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            license TEXT NOT NULL UNIQUE,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            ambulance_id TEXT NOT NULL,
            status TEXT DEFAULT 'Available',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS hospitals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id TEXT UNIQUE,
            hospital_name TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            total_beds INTEGER NOT NULL,
            available_beds INTEGER NOT NULL,
            contact_number TEXT NOT NULL,
            emergency_support INTEGER DEFAULT 0
        )`,
        `CREATE TABLE IF NOT EXISTS hospital_staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )`,
        `CREATE TABLE IF NOT EXISTS ambulance_locations (
            ambulance_id TEXT PRIMARY KEY,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`
    ];

    queries.forEach(sql => {
        db.run(sql, (err) => {
            if (err) console.error('DB init error:', err.message);
        });
    });

    db.get('SELECT COUNT(*) as count FROM hospitals', [], (err, row) => {
        if (!err && row.count === 0) {
            const insertStmt = db.prepare(`INSERT INTO hospitals 
                (hospital_id, hospital_name, latitude, longitude, total_beds, available_beds, contact_number, emergency_support)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
            [
                ['HSP-001', 'CityCare Hospital', 13.0827, 80.2707, 48, 14, '+91 90000 11111', 1],
                ['HSP-002', 'Metro Heart Institute', 13.0727, 80.2907, 36, 6, '+91 90000 22222', 1],
                ['HSP-003', 'Lifeline Trauma Center', 13.1027, 80.2607, 30, 2, '+91 90000 33333', 1]
            ].forEach(entry => insertStmt.run(entry));
            insertStmt.finalize();
        }
    });

    db.get('SELECT COUNT(*) as count FROM hospital_staff', [], async (err, row) => {
        if (!err && row.count === 0) {
            const hash = await bcrypt.hash('rapidpass', 10);
            db.run(`INSERT INTO hospital_staff (hospital_id, name, email, password_hash)
                    VALUES (1, 'CityCare Admin', 'citycare@rapidaid.io', ?)`, [hash]);
        }
    });
}

// ------------------- Utility Functions -------------------
function haversineDistance(lat1, lon1, lat2, lon2) {
    const toRad = deg => (deg * Math.PI) / 180;
    const R = 6371;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) ** 2;
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function authenticate(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'Missing Authorization header' });
    const token = authHeader.split(' ')[1];
    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ error: 'Invalid token' });
        req.user = decoded;
        next();
    });
}

// ------------------- Ambulance Tracking -------------------
app.post('/api/ambulances/:id/location', (req, res) => {
    const { lat, lng } = req.body;
    const ambulanceId = req.params.id;
    if (typeof lat !== 'number' || typeof lng !== 'number') {
        return res.status(400).json({ error: 'lat and lng must be numbers' });
    }

    const sql = `INSERT INTO ambulance_locations (ambulance_id, latitude, longitude, updated_at)
                 VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(ambulance_id) DO UPDATE SET
                    latitude = excluded.latitude,
                    longitude = excluded.longitude,
                    updated_at = CURRENT_TIMESTAMP`;
    db.run(sql, [ambulanceId, lat, lng], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        const payload = { ambulanceId, lat, lng, updatedAt: new Date().toISOString() };
        io.emit('ambulance-location', payload);
        res.json({ message: 'Location updated', ...payload });
    });
});

app.get('/api/ambulances/:id/location', (req, res) => {
    db.get('SELECT * FROM ambulance_locations WHERE ambulance_id = ?', [req.params.id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ error: 'Ambulance not found' });
        res.json(row);
    });
});

// ------------------- Hospital APIs -------------------
app.get('/api/hospitals', (req, res) => {
    db.all('SELECT * FROM hospitals', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.patch('/api/hospitals/:id/beds', authenticate, (req, res) => {
    const { available_beds } = req.body;
    if (typeof available_beds !== 'number' || available_beds < 0) {
        return res.status(400).json({ error: 'available_beds must be a positive number' });
    }
    db.run('UPDATE hospitals SET available_beds = ? WHERE id = ?', [available_beds, req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Hospital not found' });
        res.json({ message: 'Availability updated' });
    });
});

// ------------------- Nearest Hospitals -------------------
app.get('/api/nearest-hospitals', (req, res) => {
    const { lat, lng, limit = 5 } = req.query;
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
        return res.status(400).json({ error: 'lat and lng query params are required' });
    }
    db.all('SELECT * FROM hospitals', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        const sorted = rows.map(h => ({
            ...h,
            distance_km: haversineDistance(latitude, longitude, h.latitude, h.longitude)
        })).sort((a, b) => a.distance_km - b.distance_km).slice(0, parseInt(limit, 10));
        res.json(sorted);
    });
});

// ------------------- Route Calculation -------------------
app.get('/api/route', async (req, res) => {
    const { startLat, startLng, endLat, endLng } = req.query;
    if ([startLat, startLng, endLat, endLng].some(v => typeof v === 'undefined')) {
        return res.status(400).json({ error: 'startLat, startLng, endLat, endLng are required' });
    }
    if (!ORS_API_KEY) {
        return res.status(200).json({ warning: 'ORS_API_KEY not set. Provide a key to enable live routing.' });
    }
    try {
        const response = await axios.post('https://api.openrouteservice.org/v2/directions/driving-car/geojson', {
            coordinates: [
                [parseFloat(startLng), parseFloat(startLat)],
                [parseFloat(endLng), parseFloat(endLat)]
            ]
        }, {
            headers: {
                Authorization: ORS_API_KEY,
                'Content-Type': 'application/json'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Route error:', error.response?.data || error.message);
        res.status(500).json({ error: 'Failed to fetch route details' });
    }
});

// ------------------- Hospital Detail w/ ETA -------------------
app.get('/api/hospitals/:id/details', (req, res) => {
    const { ambulanceLat, ambulanceLng } = req.query;
    db.get('SELECT * FROM hospitals WHERE id = ? OR hospital_id = ?', [req.params.id, req.params.id], (err, hospital) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!hospital) return res.status(404).json({ error: 'Hospital not found' });
        let etaMinutes = null;
        if (ambulanceLat && ambulanceLng) {
            const distance = haversineDistance(parseFloat(ambulanceLat), parseFloat(ambulanceLng), hospital.latitude, hospital.longitude);
            etaMinutes = Math.round((distance / 40) * 60); // assume 40km/h avg
        }
        res.json({
            name: hospital.hospital_name,
            address: `${hospital.hospital_name}, Chennai`,
            contact: hospital.contact_number,
            totalBeds: hospital.total_beds,
            availableBeds: hospital.available_beds,
            emergencySupport: !!hospital.emergency_support,
            coordinates: { lat: hospital.latitude, lng: hospital.longitude },
            etaMinutes
        });
    });
});

// ------------------- Authentication -------------------
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    db.get('SELECT hospital_staff.*, hospitals.hospital_name FROM hospital_staff JOIN hospitals ON hospitals.id = hospital_staff.hospital_id WHERE email = ?', [email], async (err, staff) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!staff) return res.status(401).json({ error: 'Invalid credentials' });
        const valid = await bcrypt.compare(password, staff.password_hash);
        if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
        const token = jwt.sign({ staffId: staff.id, hospitalId: staff.hospital_id, email: staff.email }, JWT_SECRET, { expiresIn: '8h' });
        res.json({ token, staff: { id: staff.id, name: staff.name, hospital: staff.hospital_name } });
    });
});

// ------------------- Patients & Drivers (existing endpoints) -------------------
app.get('/api/patients', (req, res) => {
    db.all('SELECT * FROM patients ORDER BY created_at DESC', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.get('/api/patients/:id', (req, res) => {
    db.get('SELECT * FROM patients WHERE id = ?', [req.params.id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ error: 'Patient not found' });
        res.json(row);
    });
});

app.post('/api/patients', (req, res) => {
    const { name, age, phone, severity, condition, hospital, status } = req.body;
    if (!name || !age || !phone || !severity || !hospital) return res.status(400).json({ error: 'Missing required fields' });
    db.run('INSERT INTO patients (name, age, phone, severity, condition, hospital, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [name, age, phone, severity, condition || '', hospital, status || 'Active'],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ id: this.lastID, message: 'Patient created successfully' });
        });
});

app.put('/api/patients/:id', (req, res) => {
    const { name, age, phone, severity, condition, hospital, status } = req.body;
    db.run('UPDATE patients SET name = ?, age = ?, phone = ?, severity = ?, condition = ?, hospital = ?, status = ? WHERE id = ?',
        [name, age, phone, severity, condition, hospital, status, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            if (this.changes === 0) return res.status(404).json({ error: 'Patient not found' });
            res.json({ message: 'Patient updated successfully' });
        });
});

app.delete('/api/patients/:id', (req, res) => {
    db.run('DELETE FROM patients WHERE id = ?', [req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Patient not found' });
        res.json({ message: 'Patient deleted successfully' });
    });
});

app.get('/api/drivers', (req, res) => {
    db.all('SELECT * FROM drivers ORDER BY created_at DESC', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.get('/api/drivers/:id', (req, res) => {
    db.get('SELECT * FROM drivers WHERE id = ?', [req.params.id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ error: 'Driver not found' });
        res.json(row);
    });
});

app.post('/api/drivers', (req, res) => {
    const { name, license, phone, email, ambulance_id, status } = req.body;
    if (!name || !license || !phone || !email || !ambulance_id) return res.status(400).json({ error: 'Missing required fields' });
    db.run('INSERT INTO drivers (name, license, phone, email, ambulance_id, status) VALUES (?, ?, ?, ?, ?, ?)',
        [name, license, phone, email, ambulance_id, status || 'Available'],
        function(err) {
            if (err) {
                if (err.message.includes('UNIQUE constraint')) return res.status(400).json({ error: 'License already exists' });
                return res.status(500).json({ error: err.message });
            }
            res.json({ id: this.lastID, message: 'Driver created successfully' });
        });
});

app.put('/api/drivers/:id', (req, res) => {
    const { name, license, phone, email, ambulance_id, status } = req.body;
    db.run('UPDATE drivers SET name = ?, license = ?, phone = ?, email = ?, ambulance_id = ?, status = ? WHERE id = ?',
        [name, license, phone, email, ambulance_id, status, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            if (this.changes === 0) return res.status(404).json({ error: 'Driver not found' });
            res.json({ message: 'Driver updated successfully' });
        });
});

app.delete('/api/drivers/:id', (req, res) => {
    db.run('DELETE FROM drivers WHERE id = ?', [req.params.id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Driver not found' });
        res.json({ message: 'Driver deleted successfully' });
    });
});

// ------------------- Static -------------------
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// ------------------- Socket.IO -------------------
io.on('connection', (socket) => {
    console.log('Client connected', socket.id);
    socket.on('disconnect', () => console.log('Client disconnected', socket.id));
});

// ------------------- Server Start & Shutdown -------------------
server.listen(PORT, () => {
    console.log(`🚑 rapidAid server running on http://localhost:${PORT}`);
    console.log(`📊 API endpoints available at http://localhost:${PORT}/api/`);
});

process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err.message);
        } else {
            console.log('Database connection closed');
        }
        process.exit(0);
    });
});

