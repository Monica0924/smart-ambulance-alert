// -------------------------------------------------------
// Global State & Static Data
// -------------------------------------------------------
let ambulances = [];
let currentView = 'dashboard';
const maps = { dashboard: null, hospital: null, driver: null };
let hospitalMarkers = [];
let selectedHospital = null;
let routeLine = null;
let routeVisible = true;
let sheetTouchStartY = null;

const hospitalData = [
    {
        id: 'HSP-001',
        name: 'CityCare Hospital',
        lat: 13.0827,
        lng: 80.2707,
        availableBeds: 14,
        totalBeds: 48,
        icuBeds: 4,
        status: 'green',
        emergency: 'Emergency ward ready · Trauma unit active',
        contact: '+91 90000 11111'
    },
    {
        id: 'HSP-002',
        name: 'Metro Heart Institute',
        lat: 13.0727,
        lng: 80.2907,
        availableBeds: 6,
        totalBeds: 36,
        icuBeds: 3,
        status: 'yellow',
        emergency: 'ICU filling up · Cardiac wing busy',
        contact: '+91 90000 22222'
    },
    {
        id: 'HSP-003',
        name: 'Lifeline Trauma Center',
        lat: 13.1027,
        lng: 80.2607,
        availableBeds: 2,
        totalBeds: 30,
        icuBeds: 1,
        status: 'red',
        emergency: 'On divert · Ventilator wait-list',
        contact: '+91 90000 33333'
    }
];

const driverRoster = [
    { name: 'Arjun Mehta', status: 'On Duty', ambulance: 'AMB-001' },
    { name: 'Priya Venkat', status: 'Available', ambulance: 'AMB-004' },
    { name: 'Rahul Singh', status: 'On Duty', ambulance: 'AMB-002' },
    { name: 'Sneha Iyer', status: 'Break', ambulance: 'AMB-003' }
];

// Backend configuration (for Management view)
const API_BASE_URL = 'http://localhost:3000/api';
let backendAvailable = false;

// -------------------------------------------------------
// Bootstrap
// -------------------------------------------------------
document.addEventListener('DOMContentLoaded', async () => {
    await checkBackend();
    initializeNavigation();
    initializeBottomNav();
    initializeMaps();
    initializeAmbulances();
    initializeSheetInteractions();
    populateDashboardOverviews();
    startSimulation();
    initializeManagement();
    if (!backendAvailable) showBackendWarning();
});

// -------------------------------------------------------
// Navigation / Layout Helpers
// -------------------------------------------------------
function initializeNavigation() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const view = btn.getAttribute('data-view');
            switchView(view);
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });
}

function initializeBottomNav() {
    document.querySelectorAll('.bottom-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const view = btn.getAttribute('data-view');
            const section = btn.getAttribute('data-section');
            switchView(view);
            if (section === 'tracking') {
                document.getElementById('map')?.scrollIntoView({ behavior: 'smooth' });
            }
            document.querySelectorAll('.bottom-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    document.getElementById('refresh-dashboard')?.addEventListener('click', () => {
        document.getElementById('last-sync').textContent = 'Just now';
        populateDashboardOverviews();
    });

    document.getElementById('quick-add-patient')?.addEventListener('click', () => openPatientModal());
    document.getElementById('quick-add-driver')?.addEventListener('click', () => openDriverModal());

    document.getElementById('toggle-route')?.addEventListener('click', (e) => {
        routeVisible = !routeVisible;
        e.currentTarget.classList.toggle('chip-primary', routeVisible);
        if (!routeVisible && routeLine) {
            maps.dashboard?.removeLayer(routeLine);
            routeLine = null;
        } else if (routeVisible && selectedHospital) {
            drawRouteToHospital(selectedHospital);
        }
    });

    document.getElementById('center-on-ambulance')?.addEventListener('click', () => {
        const amb = ambulances[0];
        if (amb && maps.dashboard) maps.dashboard.setView([amb.lat, amb.lng], 13, { animate: true });
    });
}

function switchView(view) {
    currentView = view;
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById(`${view}-view`).classList.add('active');

    if (view === 'dashboard' && !maps.dashboard) {
        initializeDashboardMap();
    } else if (view === 'hospital' && !maps.hospital) {
        initializeHospitalMap();
    } else if (view === 'driver' && !maps.driver) {
        initializeDriverMap();
    } else if (view === 'management') {
        loadPatients();
        loadDrivers();
    }

    populateDashboardOverviews();
}

// -------------------------------------------------------
// Maps & Tracking
// -------------------------------------------------------
function initializeMaps() {
    initializeDashboardMap();
    initializeHospitalMap();
    initializeDriverMap();
}

function initializeDashboardMap() {
    const map = L.map('map').setView([13.0827, 80.2707], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    maps.dashboard = map;
    renderHospitalMarkers(map);
    updateDashboardMap();
}

function initializeHospitalMap() {
    const map = L.map('hospital-map').setView([13.0827, 80.2707], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    hospitalData.forEach(hospital => {
        L.marker([hospital.lat, hospital.lng], { icon: createHospitalIcon(hospital.status) })
            .addTo(map)
            .bindPopup(`<b>${hospital.name}</b><br>${hospital.emergency}`);
    });
    maps.hospital = map;
    updateHospitalMap();
}

function initializeDriverMap() {
    const map = L.map('driver-map').setView([13.0827, 80.2707], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    maps.driver = map;
    updateDriverMap();
}

function initializeAmbulances() {
    ambulances = [
        { id: 'AMB-001', name: 'Ambulance 1', lat: 13.0927, lng: 80.2807, status: 'en-route', destination: 'CityCare Hospital', patient: 'John Doe', severity: 'High', eta: '12:45', distance: 8.5, speed: 45 },
        { id: 'AMB-002', name: 'Ambulance 2', lat: 13.0727, lng: 80.2607, status: 'en-route', destination: 'Metro Heart Institute', patient: 'Jane Smith', severity: 'Medium', eta: '15:30', distance: 12.3, speed: 50 },
        { id: 'AMB-003', name: 'Ambulance 3', lat: 13.0827, lng: 80.2507, status: 'en-route', destination: 'Lifeline Trauma Center', patient: 'Robert Johnson', severity: 'Critical', eta: '10:20', distance: 5.2, speed: 55 }
    ];
    updateAmbulanceList();
    updateDashboardMap();
    updateHospitalAlerts();
}

function updateDashboardMap() {
    const map = maps.dashboard;
    if (!map) return;

    map.eachLayer(layer => {
        const iconClass = layer?.options?.icon?.options?.className;
        if (layer instanceof L.Marker && iconClass === 'ambulance-marker') map.removeLayer(layer);
    });

    ambulances.forEach(amb => {
        const marker = L.marker([amb.lat, amb.lng], { icon: createAmbulanceIcon(), zIndexOffset: 1000 }).addTo(map);
        marker.bindPopup(`
            <b>${amb.name}</b><br>
            Patient: ${amb.patient}<br>
            Severity: ${amb.severity}<br>
            Destination: ${amb.destination}<br>
            ETA: ${amb.eta}
        `);
    });
}

function updateAmbulanceList() {
    const list = document.getElementById('ambulance-list');
    if (!list) return;
    list.innerHTML = ambulances.map(amb => `
        <div class="ambulance-card">
            <h3>${amb.name}</h3>
            <p><strong>Status:</strong> <span class="status-badge ${amb.status}">${amb.status}</span></p>
            <p><strong>Patient:</strong> ${amb.patient}</p>
            <p><strong>Severity:</strong> ${amb.severity}</p>
            <p><strong>Destination:</strong> ${amb.destination}</p>
            <p><strong>ETA:</strong> ${amb.eta}</p>
            <p><strong>Distance:</strong> ${amb.distance.toFixed(1)} km</p>
        </div>
    `).join('');
}

function updateHospitalAlerts() {
    const alertsContainer = document.getElementById('hospital-alerts');
    if (!alertsContainer) return;
    alertsContainer.innerHTML = hospitalData.map(hospital => `
        <div class="alert-card">
            <h3>🚨 ${hospital.name}</h3>
            <div class="alert-info">
                <div class="alert-info-item">
                    <span class="alert-info-label">Status</span>
                    <span class="alert-info-value">${hospital.status}</span>
                </div>
                <div class="alert-info-item">
                    <span class="alert-info-label">Emergency</span>
                    <span class="alert-info-value">${hospital.emergency}</span>
                </div>
                <div class="alert-info-item">
                    <span class="alert-info-label">Beds</span>
                    <span class="alert-info-value">${hospital.availableBeds}/${hospital.totalBeds}</span>
                </div>
            </div>
        </div>
    `).join('');
}

function updateHospitalMap() {
    const map = maps.hospital;
    if (!map) return;
    map.eachLayer(layer => {
        const iconClass = layer?.options?.icon?.options?.className;
        if (layer instanceof L.Marker && iconClass === 'ambulance-marker') map.removeLayer(layer);
    });

    ambulances.forEach(amb => {
        L.marker([amb.lat, amb.lng], { icon: createAmbulanceIcon(), zIndexOffset: 800 })
            .addTo(map)
            .bindPopup(`<b>${amb.name}</b><br>Patient: ${amb.patient}<br>ETA: ${amb.eta}`);
    });
}

function updateDriverMap() {
    if (!maps.driver || !ambulances.length) return;
    const driverAmbulance = ambulances[0];
    document.getElementById('patient-name').textContent = driverAmbulance.patient;
    document.getElementById('patient-severity').textContent = driverAmbulance.severity;
    document.getElementById('destination-hospital').textContent = driverAmbulance.destination;
    document.getElementById('driver-eta').textContent = driverAmbulance.eta;
    document.getElementById('route-distance').textContent = `${driverAmbulance.distance.toFixed(1)} km`;
    document.getElementById('route-time').textContent = `${Math.round(driverAmbulance.distance / driverAmbulance.speed * 60)} min`;

    maps.driver.eachLayer(layer => {
        if (layer instanceof L.Marker || layer instanceof L.Polyline) maps.driver.removeLayer(layer);
    });

    L.marker([driverAmbulance.lat, driverAmbulance.lng], { icon: createAmbulanceIcon(), zIndexOffset: 1000 }).addTo(maps.driver);
    const destHospital = hospitalData.find(h => h.name === driverAmbulance.destination) || hospitalData[0];
    L.marker([destHospital.lat, destHospital.lng], { icon: createHospitalIcon(destHospital.status) }).addTo(maps.driver);

    L.polyline([[driverAmbulance.lat, driverAmbulance.lng], [destHospital.lat, destHospital.lng]], {
        color: '#0b5ed7', weight: 4, dashArray: '6 10', opacity: 0.7
    }).addTo(maps.driver);

    maps.driver.fitBounds([[driverAmbulance.lat, driverAmbulance.lng], [destHospital.lat, destHospital.lng]]);
}

// -------------------------------------------------------
// Hospital Marker / Sheet Interactions
// -------------------------------------------------------
function renderHospitalMarkers(map) {
    hospitalMarkers.forEach(entry => map.removeLayer(entry.marker));
    hospitalMarkers = hospitalData.map(hospital => {
        const marker = L.marker([hospital.lat, hospital.lng], { icon: createHospitalIcon(hospital.status) }).addTo(map);
        marker.bindTooltip(hospital.name, { direction: 'top' });
        marker.on('click', () => handleHospitalSelect(hospital, marker));
        return { id: hospital.id, marker };
    });
}

function handleHospitalSelect(hospital, marker) {
    selectedHospital = hospital;
    hospitalMarkers.forEach(entry => entry.marker.getElement()?.classList.remove('active'));
    marker.getElement()?.classList.add('active');
    if (routeVisible) drawRouteToHospital(hospital);
    openHospitalSheet(hospital);
}

function drawRouteToHospital(hospital) {
    if (!maps.dashboard || !ambulances.length) return;
    if (routeLine) maps.dashboard.removeLayer(routeLine);
    const amb = ambulances[0];
    routeLine = L.polyline([[amb.lat, amb.lng], [hospital.lat, hospital.lng]], {
        color: '#0b5ed7', weight: 4, dashArray: '10 8', opacity: 0.7
    }).addTo(maps.dashboard);
}

function initializeSheetInteractions() {
    const sheet = document.getElementById('hospital-info-sheet');
    const overlay = document.getElementById('hospital-sheet-overlay');
    document.getElementById('close-sheet')?.addEventListener('click', closeHospitalSheet);
    overlay?.addEventListener('click', closeHospitalSheet);

    sheet?.addEventListener('touchstart', (e) => {
        sheetTouchStartY = e.touches[0].clientY;
    });

    sheet?.addEventListener('touchmove', (e) => {
        if (!sheetTouchStartY) return;
        const diff = e.touches[0].clientY - sheetTouchStartY;
        if (diff > 80) {
            closeHospitalSheet();
            sheetTouchStartY = null;
        }
    });
}

function openHospitalSheet(hospital) {
    const sheet = document.getElementById('hospital-info-sheet');
    const overlay = document.getElementById('hospital-sheet-overlay');
    if (!sheet || !overlay) return;

    const amb = ambulances[0];
    const distance = amb ? calculateDistance(amb.lat, amb.lng, hospital.lat, hospital.lng).toFixed(1) : '--';
    const eta = amb ? Math.max(4, Math.round((distance / amb.speed) * 60)) : '--';

    document.getElementById('sheet-hospital-name').textContent = hospital.name;
    document.getElementById('sheet-distance').textContent = `${distance} km`;
    document.getElementById('sheet-eta').textContent = `${eta} min`;
    document.getElementById('sheet-beds-available').textContent = hospital.availableBeds;
    document.getElementById('sheet-beds-total').textContent = hospital.totalBeds;
    document.getElementById('sheet-icu-beds').textContent = hospital.icuBeds;
    const statusEl = document.getElementById('sheet-status');
    statusEl.className = `status-tag ${hospital.status}`;
    statusEl.textContent = hospital.status === 'green' ? 'Available' : hospital.status === 'yellow' ? 'Moderate' : 'Full';
    document.getElementById('sheet-emergency').textContent = hospital.emergency;
    const contactEl = document.getElementById('sheet-contact');
    contactEl.textContent = hospital.contact;
    contactEl.setAttribute('href', `tel:${hospital.contact}`);
    document.getElementById('sheet-navigate').setAttribute('href', `https://www.google.com/maps/dir/?api=1&destination=${hospital.lat},${hospital.lng}`);
    document.getElementById('sheet-alert').onclick = () => alert(`Alert sent to ${hospital.name}`);

    overlay.classList.add('show');
    sheet.classList.add('show');
}

function closeHospitalSheet() {
    document.getElementById('hospital-sheet-overlay')?.classList.remove('show');
    document.getElementById('hospital-info-sheet')?.classList.remove('show');
}

function createAmbulanceIcon() {
    return L.divIcon({
        className: 'ambulance-marker',
        html: '<div class="pulse"></div><div class="car">🚑</div>',
        iconSize: [40, 40],
        iconAnchor: [20, 40]
    });
}

function createHospitalIcon(status = 'green') {
    return L.divIcon({
        className: `hospital-pin ${status}`,
        html: '<div class="pin-body"><span>+</span></div>',
        iconSize: [50, 50],
        iconAnchor: [25, 45]
    });
}

// -------------------------------------------------------
// Simulation & Controls
// -------------------------------------------------------
function startSimulation() {
    setInterval(() => {
        ambulances.forEach(amb => {
            const dest = hospitalData.find(h => h.name === amb.destination) || hospitalData[0];
            const latDiff = dest.lat - amb.lat;
            const lngDiff = dest.lng - amb.lng;
            amb.lat += latDiff * 0.001;
            amb.lng += lngDiff * 0.001;
            amb.distance = calculateDistance(amb.lat, amb.lng, dest.lat, dest.lng);
            const timeMinutes = Math.max(1, Math.round((amb.distance / amb.speed) * 60));
            const etaTime = new Date(Date.now() + timeMinutes * 60000);
            amb.eta = etaTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        });

        if (currentView === 'dashboard') {
            updateDashboardMap();
            updateAmbulanceList();
        } else if (currentView === 'hospital') {
            updateHospitalMap();
            updateHospitalAlerts();
        } else if (currentView === 'driver') {
            updateDriverMap();
        }

        if (selectedHospital && routeVisible) {
            drawRouteToHospital(selectedHospital);
            openHospitalSheet(selectedHospital);
        }
    }, 2000);
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

document.getElementById('start-route')?.addEventListener('click', () => alert('Navigation started! Follow the route on the map.'));
document.getElementById('update-location')?.addEventListener('click', () => {
    alert('Location updated! Hospital has been notified.');
    if (ambulances.length > 0) {
        ambulances[0].lat += 0.001;
        ambulances[0].lng += 0.001;
        updateDriverMap();
    }
});
document.getElementById('emergency-stop')?.addEventListener('click', () => {
    if (confirm('Are you sure you want to trigger an emergency stop?')) alert('Emergency stop activated! Control room and hospital have been notified.');
});

// -------------------------------------------------------
// Dashboard Overview Cards
// -------------------------------------------------------
function populateDashboardOverviews() {
    const patientSection = document.getElementById('patient-overview');
    const driverSection = document.getElementById('driver-overview');
    const alertSection = document.getElementById('alert-overview');

    if (patientSection) {
        patientSection.innerHTML = ambulances.map(amb => `
            <div class="overview-item">
                <div>
                    <strong>${amb.patient}</strong>
                    <p class="mini-text">${amb.destination}</p>
                </div>
                <span class="status-badge ${amb.severity.toLowerCase()}">${amb.severity}</span>
            </div>
        `).join('');
    }

    if (driverSection) {
        driverSection.innerHTML = driverRoster.map(driver => `
            <div class="overview-item">
                <div>
                    <strong>${driver.name}</strong>
                    <p class="mini-text">Ambulance ${driver.ambulance}</p>
                </div>
                <span class="status-badge ${driver.status.toLowerCase().replace(' ', '-')}">${driver.status}</span>
            </div>
        `).join('');
    }

    if (alertSection) {
        const activeHospitals = hospitalData.filter(h => h.status !== 'green');
        document.getElementById('active-alert-count').textContent = `${activeHospitals.length} Active`;
        alertSection.innerHTML = activeHospitals.length
            ? activeHospitals.map(hospital => `
                <div class="overview-item">
                    <div>
                        <strong>${hospital.name}</strong>
                        <p class="mini-text">${hospital.emergency}</p>
                    </div>
                    <span class="status-tag ${hospital.status}">${hospital.status}</span>
                </div>
            `).join('')
            : '<p>All hospitals clear.</p>';
    }
}

// -------------------------------------------------------
// Backend / Management (existing functionality)
// -------------------------------------------------------
async function checkBackend() {
    try {
        await fetch(`${API_BASE_URL}/patients`);
        backendAvailable = true;
    } catch (error) {
        backendAvailable = false;
        console.warn('Backend server not available. Management features will be limited.');
    }
}

function showBackendWarning() {
    const warning = document.createElement('div');
    warning.style.cssText = `
        position: fixed; top: 80px; right: 20px; background: #f59e0b; color: white;
        padding: 1rem 1.5rem; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        z-index: 2000; max-width: 400px; animation: slideIn 0.3s ease;
    `;
    warning.innerHTML = `
        <strong>⚠️ Backend Not Connected</strong><br>
        <small>Management features require the backend server. The frontend will work for viewing, but data won't be saved.</small>
        <br><br>
        <small>To enable full features, install Node.js and run: <code>npm start</code></small>
    `;
    document.body.appendChild(warning);
    setTimeout(() => warning.remove(), 10000);
}

// Patient Management Functions
async function loadPatients() {
    if (!backendAvailable) {
        document.getElementById('patients-table-body').innerHTML =
            '<tr><td colspan="6" style="text-align: center; color:#ef4444; padding:2rem;">⚠️ Backend server not available. Please run <code>npm start</code>.</td></tr>';
        return;
    }
    try {
        const response = await fetch(`${API_BASE_URL}/patients`);
        const patients = await response.json();
        renderPatientsTable(patients);
    } catch (error) {
        document.getElementById('patients-table-body').innerHTML =
            '<tr><td colspan="6" style="text-align:center; color:#ef4444;">Error loading patients.</td></tr>';
    }
}

function renderPatientsTable(patients) {
    const tbody = document.getElementById('patients-table-body');
    if (!patients.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#6b7280;">No patients found.</td></tr>';
        return;
    }
    tbody.innerHTML = patients.map(patient => `
        <tr>
            <td>${patient.id}</td>
            <td>${patient.name}</td>
            <td>${patient.age}</td>
            <td><span class="status-badge ${patient.severity.toLowerCase()}">${patient.severity}</span></td>
            <td><span class="status-badge ${patient.status.toLowerCase().replace(' ', '-')}">${patient.status}</span></td>
            <td>
                <button class="action-btn edit" onclick="editPatient(${patient.id})"><i class="fas fa-edit"></i></button>
                <button class="action-btn delete" onclick="deletePatient(${patient.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

async function loadDrivers() {
    if (!backendAvailable) {
        document.getElementById('drivers-table-body').innerHTML =
            '<tr><td colspan="6" style="text-align: center; color:#ef4444; padding:2rem;">⚠️ Backend server not available. Please run <code>npm start</code>.</td></tr>';
        return;
    }
    try {
        const response = await fetch(`${API_BASE_URL}/drivers`);
        const drivers = await response.json();
        renderDriversTable(drivers);
    } catch (error) {
        document.getElementById('drivers-table-body').innerHTML =
            '<tr><td colspan="6" style="text-align:center; color:#ef4444;">Error loading drivers.</td></tr>';
    }
}

function renderDriversTable(drivers) {
    const tbody = document.getElementById('drivers-table-body');
    if (!drivers.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#6b7280;">No drivers found.</td></tr>';
        return;
    }
    tbody.innerHTML = drivers.map(driver => `
        <tr>
            <td>${driver.id}</td>
            <td>${driver.name}</td>
            <td>${driver.license}</td>
            <td>${driver.phone}</td>
            <td><span class="status-badge ${driver.status.toLowerCase().replace(' ', '-')}">${driver.status}</span></td>
            <td>
                <button class="action-btn edit" onclick="editDriver(${driver.id})"><i class="fas fa-edit"></i></button>
                <button class="action-btn delete" onclick="deleteDriver(${driver.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

async function createPatient(patientData) {
    try {
        const response = await fetch(`${API_BASE_URL}/patients`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(patientData)
        });
        const result = await response.json();
        if (response.ok) {
            alert('Patient created successfully!');
            closePatientModal();
            loadPatients();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error creating patient. Make sure the backend server is running.');
    }
}

async function updatePatient(id, patientData) {
    try {
        const response = await fetch(`${API_BASE_URL}/patients/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(patientData)
        });
        const result = await response.json();
        if (response.ok) {
            alert('Patient updated successfully!');
            closePatientModal();
            loadPatients();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error updating patient. Make sure the backend server is running.');
    }
}

async function deletePatient(id) {
    if (!confirm('Are you sure you want to delete this patient?')) return;
    try {
        const response = await fetch(`${API_BASE_URL}/patients/${id}`, { method: 'DELETE' });
        const result = await response.json();
        if (response.ok) {
            alert('Patient deleted successfully!');
            loadPatients();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error deleting patient. Make sure the backend server is running.');
    }
}

async function editPatient(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/patients/${id}`);
        const patient = await response.json();

        document.getElementById('patient-id').value = patient.id;
        document.getElementById('patient-name-input').value = patient.name;
        document.getElementById('patient-age').value = patient.age;
        document.getElementById('patient-phone').value = patient.phone;
        document.getElementById('patient-severity-input').value = patient.severity;
        document.getElementById('patient-condition').value = patient.condition || '';
        document.getElementById('patient-hospital').value = patient.hospital;
        document.getElementById('patient-modal-title').textContent = 'Edit Patient';

        openPatientModal();
    } catch (error) {
        alert('Error loading patient details.');
    }
}

async function createDriver(driverData) {
    try {
        const response = await fetch(`${API_BASE_URL}/drivers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(driverData)
        });
        const result = await response.json();
        if (response.ok) {
            alert('Driver created successfully!');
            closeDriverModal();
            loadDrivers();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error creating driver. Make sure the backend server is running.');
    }
}

async function updateDriver(id, driverData) {
    try {
        const response = await fetch(`${API_BASE_URL}/drivers/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(driverData)
        });
        const result = await response.json();
        if (response.ok) {
            alert('Driver updated successfully!');
            closeDriverModal();
            loadDrivers();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error updating driver. Make sure the backend server is running.');
    }
}

async function deleteDriver(id) {
    if (!confirm('Are you sure you want to delete this driver?')) return;
    try {
        const response = await fetch(`${API_BASE_URL}/drivers/${id}`, { method: 'DELETE' });
        const result = await response.json();
        if (response.ok) {
            alert('Driver deleted successfully!');
            loadDrivers();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        alert('Error deleting driver. Make sure the backend server is running.');
    }
}

async function editDriver(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/drivers/${id}`);
        const driver = await response.json();

        document.getElementById('driver-id').value = driver.id;
        document.getElementById('driver-name-input').value = driver.name;
        document.getElementById('driver-license').value = driver.license;
        document.getElementById('driver-phone').value = driver.phone;
        document.getElementById('driver-email').value = driver.email;
        document.getElementById('driver-ambulance-id').value = driver.ambulance_id;
        document.getElementById('driver-status-input').value = driver.status;
        document.getElementById('driver-modal-title').textContent = 'Edit Driver';

        openDriverModal();
    } catch (error) {
        alert('Error loading driver details.');
    }
}

// Modal helpers
function openPatientModal() {
    document.getElementById('patient-modal').classList.add('active');
}

function closePatientModal() {
    document.getElementById('patient-modal').classList.remove('active');
    document.getElementById('patient-form').reset();
    document.getElementById('patient-id').value = '';
    document.getElementById('patient-modal-title').textContent = 'Add Patient';
}

function openDriverModal() {
    document.getElementById('driver-modal').classList.add('active');
}

function closeDriverModal() {
    document.getElementById('driver-modal').classList.remove('active');
    document.getElementById('driver-form').reset();
    document.getElementById('driver-id').value = '';
    document.getElementById('driver-modal-title').textContent = 'Add Driver';
}

function initializeManagement() {
    document.getElementById('patient-form')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('patient-id').value;
        const patientData = {
            name: document.getElementById('patient-name-input').value,
            age: parseInt(document.getElementById('patient-age').value, 10),
            phone: document.getElementById('patient-phone').value,
            severity: document.getElementById('patient-severity-input').value,
            condition: document.getElementById('patient-condition').value,
            hospital: document.getElementById('patient-hospital').value,
            status: 'Active'
        };
        if (id) {
            await updatePatient(id, patientData);
        } else {
            await createPatient(patientData);
        }
    });

    document.getElementById('driver-form')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('driver-id').value;
        const driverData = {
            name: document.getElementById('driver-name-input').value,
            license: document.getElementById('driver-license').value,
            phone: document.getElementById('driver-phone').value,
            email: document.getElementById('driver-email').value,
            ambulance_id: document.getElementById('driver-ambulance-id').value,
            status: document.getElementById('driver-status-input').value
        };
        if (id) {
            await updateDriver(id, driverData);
        } else {
            await createDriver(driverData);
        }
    });

    document.getElementById('add-patient-btn')?.addEventListener('click', openPatientModal);
    document.getElementById('close-patient-modal')?.addEventListener('click', closePatientModal);
    document.getElementById('cancel-patient')?.addEventListener('click', closePatientModal);

    document.getElementById('add-driver-btn')?.addEventListener('click', openDriverModal);
    document.getElementById('close-driver-modal')?.addEventListener('click', closeDriverModal);
    document.getElementById('cancel-driver')?.addEventListener('click', closeDriverModal);

    document.getElementById('patient-modal')?.addEventListener('click', (e) => {
        if (e.target.id === 'patient-modal') closePatientModal();
    });
    document.getElementById('driver-modal')?.addEventListener('click', (e) => {
        if (e.target.id === 'driver-modal') closeDriverModal();
    });
}

// Expose functions for inline handlers
window.editPatient = editPatient;
window.deletePatient = deletePatient;
window.editDriver = editDriver;
window.deleteDriver = deleteDriver;

