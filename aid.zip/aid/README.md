# 🚑 rapidAid - Smart Hospital Alert System

A real-time web application for tracking ambulances, notifying hospitals, and managing patient and driver information with a modern interface and full backend integration.

## ✨ Features

### 🎯 Core Functionality
- **Real-time Ambulance Tracking**: Live GPS tracking of multiple ambulances on an interactive map
- **Smart Hospital Alerts**: Automatic notifications to hospitals with patient details, ETA, and severity
- **Route Optimization**: AI-based route suggestions with traffic awareness
- **Patient Management**: Full CRUD operations for patient records
- **Driver Management**: Complete driver information management system
- **Multi-View Dashboard**: 
  - Control Room: Central monitoring for all ambulances
  - Hospital View: Incoming ambulance alerts and tracking
  - Driver App: Navigation interface for ambulance drivers
  - Management: Patient and driver management interface

### 📊 Dashboard Features
- Live map visualization with ambulance locations
- Real-time statistics (active ambulances, response times, success rates)
- Ambulance status cards with patient information
- Automatic updates every 2 seconds

### 🏥 Hospital Features
- Incoming ambulance alerts with patient details
- ETA and distance calculations
- Hospital readiness status
- Live tracking of approaching ambulances

### 🚗 Driver App Features
- Emergency call information display
- Patient severity indicators
- Route information (distance, time, traffic)
- Navigation controls
- Location update functionality

### 👥 Management Features
- Add, edit, and delete patients
- Add, edit, and delete drivers
- View all patient and driver records in tables
- Real-time data synchronization with backend

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm (Node Package Manager)

### Installation

1. **Clone or download this repository**

2. **Install backend dependencies:**
   ```bash
   npm install
   ```

3. **Start the backend server:**
   ```bash
   npm start
   ```
   The server will run on `http://localhost:3000`

4. **Open the application:**
   - Open `index.html` in your browser, OR
   - The backend server also serves the frontend at `http://localhost:3000`

## 📁 Project Structure

```
rapidAid/
├── index.html          # Main HTML file
├── styles.css          # Modern CSS styling
├── app.js              # Frontend JavaScript with API integration
├── server.js           # Express backend server
├── package.json        # Node.js dependencies
├── rapidaid.db         # SQLite database (created automatically)
└── README.md           # This file
```

## 🔧 Technology Stack

### Frontend
- **HTML5**: Structure and layout
- **CSS3**: Modern, responsive styling with gradients and animations
- **JavaScript (ES6+)**: Real-time updates and API integration
- **Leaflet.js**: Interactive map visualization
- **Font Awesome**: Icons
- **OpenStreetMap**: Map tiles

### Backend
- **Node.js + Express**: REST API + static hosting
- **SQLite3**: Persistent storage (hospitals, staff, ambulances, patients, drivers)
- **Socket.IO**: Real-time ambulance location streaming
- **JWT + bcrypt**: Secure hospital staff authentication
- **OpenRouteService / Google Directions**: Route & ETA calculation (optional API key)
- **Axios, CORS, Body Parser**: HTTP helpers & middleware

## 📡 API Endpoints

### Ambulance Tracking
- `POST /api/ambulances/:id/location` – update live GPS coordinates (emits Socket.IO event)
- `GET /api/ambulances/:id/location` – fetch current position
- `GET /api/nearest-hospitals?lat=&lng=` – Haversine-sorted nearest hospitals
- `GET /api/hospitals/:id/details` – bed data, contact, ETA (optional ambulance lat/lng)
- `GET /api/route?startLat=&startLng=&endLat=&endLng=` – driving route (OpenRouteService)

### Hospitals
- `GET /api/hospitals` – list with bed availability
- `PATCH /api/hospitals/:id/beds` – update available beds (JWT auth)

### Authentication
- `POST /api/auth/login` – hospital staff login (returns JWT token)

### Patients
- `GET /api/patients` - Get all patients
- `GET /api/patients/:id` - Get patient by ID
- `POST /api/patients` - Create new patient
- `PUT /api/patients/:id` - Update patient
- `DELETE /api/patients/:id` - Delete patient

### Drivers
- `GET /api/drivers` - Get all drivers
- `GET /api/drivers/:id` - Get driver by ID
- `POST /api/drivers` - Create new driver
- `PUT /api/drivers/:id` - Update driver
- `DELETE /api/drivers/:id` - Delete driver

## 💾 Database Schema

### Patients Table
- `id` (INTEGER, PRIMARY KEY)
- `name` (TEXT, NOT NULL)
- `age` (INTEGER, NOT NULL)
- `phone` (TEXT, NOT NULL)
- `severity` (TEXT, NOT NULL)
- `condition` (TEXT)
- `hospital` (TEXT, NOT NULL)
- `status` (TEXT, DEFAULT 'Active')
- `created_at` (DATETIME)

### Drivers Table
- `id` (INTEGER, PRIMARY KEY)
- `name` (TEXT, NOT NULL)
- `license` (TEXT, NOT NULL, UNIQUE)
- `phone` (TEXT, NOT NULL)
- `email` (TEXT, NOT NULL)
- `ambulance_id` (TEXT, NOT NULL)
- `status` (TEXT, DEFAULT 'Available')
- `created_at` (DATETIME)

### Hospitals Table
- `hospital_id`, `hospital_name`
- `latitude`, `longitude`
- `total_beds`, `available_beds`
- `contact_number`
- `emergency_support`

### Hospital Staff Table
- `hospital_id`
- `name`, `email`
- `password_hash`

### Ambulance Locations Table
- `ambulance_id`
- `latitude`, `longitude`
- `updated_at`

## 🎨 Interface Features

- **Modern Design**: Clean, professional interface with smooth animations
- **Responsive Layout**: Works on desktop, tablet, and mobile devices
- **Real-time Updates**: Live data synchronization
- **Modal Forms**: Easy-to-use forms for adding/editing records
- **Data Tables**: Organized display of patients and drivers
- **Interactive Maps**: Real-time ambulance tracking with markers

## 🔄 Usage

1. **Start the backend server** (required for management features)
2. **Open the application** in your browser
3. **Navigate between views** using the top navigation
4. **Add patients/drivers** from the Management view
5. **Track ambulances** in real-time on the Control Room dashboard
6. **View hospital alerts** in the Hospital View
7. **Use driver navigation** in the Driver App view

## 🛠️ Development

### Running in Development Mode
```bash
npm run dev
```
(Requires nodemon: `npm install -g nodemon`)

### Database
The SQLite database (`rapidaid.db`) is created automatically on first run. Tables are created automatically if they don't exist.

## 📝 Notes

- The application uses Chennai, India coordinates by default
- Ambulance tracking is simulated for demonstration
- For production use, integrate with real GPS hardware
- Backend server must be running for management features, hospital auth, and live tracking
- Frontend can work standalone for viewing, but backend is required for persistence + Socket.IO updates
- Create a `.env` file with `JWT_SECRET` and (optionally) `ORS_API_KEY` to enable secure auth and routing

## 🔮 Future Enhancements

- Integration with real GPS devices
- User authentication and roles
- Push notifications for hospitals
- Traffic data integration
- Historical data and analytics
- Mobile app versions (iOS/Android)
- Real-time WebSocket updates
- Hospital bed availability tracking
- Route optimization with real traffic data

## 📄 License

This project is open source and available for educational and commercial use.

## 🆘 Troubleshooting

**Backend not connecting?**
- Make sure Node.js is installed
- Run `npm install` to install dependencies
- Start the server with `npm start`
- Check that port 3000 is not in use

**Database errors?**
- The database file is created automatically
- Make sure the application has write permissions
- Delete `rapidaid.db` to reset the database

**Maps not loading?**
- Check your internet connection (maps load from OpenStreetMap)
- Ensure Leaflet.js CDN is accessible

---

**Note**: This is a demonstration application. For production use, integrate with real GPS hardware, backend services, and hospital management systems.
